<?php
// Static training placeholder; no database connection.
header("Content-Type: text/html; charset=utf-8");
?>
<!doctype html><html lang="id"><meta charset="utf-8"><title>BelanjaRaya</title><h1>BelanjaRaya</h1><p>Katalog produk</p></html>
